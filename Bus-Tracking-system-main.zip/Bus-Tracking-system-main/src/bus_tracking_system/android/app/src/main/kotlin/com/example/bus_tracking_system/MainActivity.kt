package com.example.bus_tracking_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
