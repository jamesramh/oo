import 'package:latlong2/latlong.dart';

class DestinationInfo {
  final LatLng destinationLocation;

  DestinationInfo(this.destinationLocation);
}
