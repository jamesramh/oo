import 'package:flutter/material.dart';

const String orsapikey =
    "5b3ce3597851110001cf62486114402a56174aa9b0294c6ade29f118"; //Enter the required API
const Color primaryColor = Color.fromARGB(15, 97, 150, 255);
